<?php
echo art_get_search();