<div class="art-blockheader">
    <div class="l"></div>
    <div class="r"></div>
    <h3 class="t"><?php echo $caption; ?></h3>
</div>
