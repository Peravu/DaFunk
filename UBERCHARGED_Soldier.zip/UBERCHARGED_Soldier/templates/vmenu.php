<?php echo $header; ?>
<?php echo $content; ?>
