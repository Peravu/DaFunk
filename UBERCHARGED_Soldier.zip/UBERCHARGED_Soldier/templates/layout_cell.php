<div class="art-layout-cell art-layout-cell-size<?php echo $count; ?>">
    <?php echo $content; ?> 
    <div class="cleared"> </div>
</div>