                      <div class="art-post<?php echo $post_class; ?>" <?php echo $post_id; ?>>
                          <div class="art-post-body">
                                  <div class="art-post-inner art-article">
                                      <?php echo $post_thumbnail; ?>
                                                      <?php echo $post_title; ?>
                                      <?php echo $post_metadataheader; ?>
                                      <div class="art-postcontent">
                                          <?php echo $post_content; ?>
                                      </div>
                                      <div class="cleared"></div>
                                      <?php echo $post_metadatafooter; ?>
                                  </div>
                      		<div class="cleared"></div>
                          </div>
                      </div>