<div class="art-content-layout">
    <div class="art-content-layout-row">
        <?php echo $cells; ?>  
    </div>
</div>