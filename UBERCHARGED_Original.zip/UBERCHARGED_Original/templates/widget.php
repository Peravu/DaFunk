<ul id="<?php echo $id; ?>" class="<?php echo $class; ?> art-widget">
  <?php echo $caption; ?>
  <li class="art-widget-content"><?php echo $content; ?></li>
</ul>