<div class="art-block <?php echo $class; ?>" <?php echo $id; ?>>
    <div class="art-block-body">
<?php echo $header; ?>
<div class="art-blockcontent">
    <div class="art-blockcontent-body">
<?php echo $content; ?>


		<div class="cleared"></div>
    </div>
</div>

		<div class="cleared"></div>
    </div>
</div>
