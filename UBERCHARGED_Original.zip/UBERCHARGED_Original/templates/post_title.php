                                      <h2 class="art-postheader"><a href="<?php echo $post_link; ?>" rel="bookmark" title="<?php echo $post_link_title; ?>">
                                       <?php echo $post_title; ?>
                                      </a></h2>