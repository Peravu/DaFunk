                                      <div class="art-postfootericons art-metadata-icons">
                                          <?php echo $postfootericons; ?>    
                                      </div>