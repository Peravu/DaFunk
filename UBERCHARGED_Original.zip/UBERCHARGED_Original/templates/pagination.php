                                             <div class="navigation">
                                                <div class="alignleft"><?php echo $next_link; ?></div>
                                                <div class="alignright"><?php echo $prev_link; ?></div>
                                             </div>