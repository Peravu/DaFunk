<?php
get_header(); 
art_not_found_msg(__('404. Page not found.', THEME_NS));
get_footer(); 